import math
from vex import * # Use wildcard import

# Use absolute imports from src root
from tracker import DriveTracker, Position
from main import convert_to_360_range, debug, timer # Assuming timer is needed?
from constants import LEFT, RIGHT

class Paths:
    def __init__(self, drive_tracker: DriveTracker):
        self.drive_tracker = drive_tracker

    def get_heading_to_point(self, point: Tuple):
        current_location = self.drive_tracker.position
        delta_x = point[0] - current_location.x
        delta_y = point[1] - current_location.y
        desired_heading = convert_to_360_range(math.degrees(math.atan2(delta_y, delta_x)))
        # debug(desired_heading)
        return desired_heading
    
    def print_desired_heading(self):
        while True:
            point = (24, 72)
            debug("desired heading: " + str(self.get_heading_to_point(point)))
    
    def heading_to_turn_to(self, point, dir):
        desired_heading = self.get_heading_to_point(point)
        current_heading = self.drive_tracker.inertial.heading()
        heading_gain = desired_heading - current_heading
        debug("Heading gain: " + str(heading_gain))
        if dir == REVERSE:
            heading_gain += 180 
        heading_gain %= 360
        if heading_gain > 180:
            heading_gain -= 360
        debug("Heading gain after mod: " + str(heading_gain))
        return heading_gain

    def get_heading_gain(self, point, dir):
        desired_heading = self.get_heading_to_point(point)
        current_heading = self.drive_tracker.inertial.heading()
        if dir == REVERSE:
            desired_heading = (desired_heading + 180) % 360
        heading_gain = desired_heading - current_heading
        heading_gain = (heading_gain + 180) % 360 - 180
        return heading_gain
    
    def get_signed_error_to_point(self, point):
        heading = self.drive_tracker.position.heading
        robot_point = (self.drive_tracker.position.x, self.drive_tracker.position.y)

        target_vector = [point[0] - robot_point[0], point[1] - robot_point[1]]
        heading_vector = [math.cos(math.radians(heading)), math.sin(math.radians(heading))]
        dot_product = target_vector[0] * heading_vector[0] + target_vector[1] * heading_vector[1]


        return dot_product


    def get_distance_to_point(self, point):
        distance = ((self.drive_tracker.position.x - point[0])**2 + (self.drive_tracker.position.y - point[1])**2)**0.5
        return distance 