#from typing import Any
from vex import * # Import everything from vex
import math

# Import constants and core components
from constants import drive_constants
from tracker import DriveTracker, Position, WallGuideSensor 

# Import control components
from control.path_planning import Paths
from control.movement import Movement # Import the new Movement class

# Brain should be defined by default
brain=Brain()
timer = Timer()

def convert_to_180_range(angle):
        if angle <= 180:
            return angle
        else:
            return angle - 360
    
def convert_to_360_range(angle):
    if angle > 0:
        return angle
    else:
        return angle + 360

def debug(s):
    # Simple debug function, ensure timer exists
    current_time = timer.system() if timer else 0
    print("[" + str(current_time) + "] " + str(s))


class CustomInertial:
    def __init__(self, port) -> None:
        self.inertial = Inertial(port)
        self.recorded_angle = 0
        self.total_angle = 0
    
    def calibrate(self):
        self.inertial.calibrate()
        debug("Inertial calibrating...")
        while self.is_calibrating():
            wait(50, MSEC)
        debug("Inertial calibration complete.")

    
    def is_calibrating(self):
        return self.inertial.is_calibrating()
        
    def set_heading(self, heading):
        # VEX heading is clockwise positive, 0-359.99
        # We want counter-clockwise positive internal representation
        vex_heading = (360 - heading) % 360
        self.inertial.set_heading(vex_heading, DEGREES)
        self.total_angle = heading # Store our desired representation
        debug("Inertial heading set to " + str(round(heading, 2)) + " (VEX: " + str(round(vex_heading, 2)) + ")")


    def update_turns_total(self, prev_internal_angle, current_vex_heading):
        # Convert current VEX heading to our internal representation
        current_internal_heading = (360 - current_vex_heading) % 360
        
        delta = current_internal_heading - prev_internal_angle
        # Handle angle wrap around (-180 to 180 range)
        if delta > 180:
            delta -= 360
        elif delta < -180:
            delta += 360
            
        self.total_angle += delta
        return current_internal_heading # Return the current internal angle for the next iteration
    
    def heading(self, units=DEGREES):
        # Return our internal continuous heading
        # Note: VEX units parameter is ignored here, always returns degrees
        return self.total_angle
    
    def vex_heading(self, units=DEGREES):
        # Get the raw VEX heading if needed
        return self.inertial.heading(units)
    
    def reset_heading(self):
        # Resets the VEX sensor's current angle to 0
        self.inertial.reset_heading()
        # Also reset our internal continuous angle
        self.total_angle = 0 
        debug("Inertial heading reset.")
    
    def reset_total_turned(self):
        # Only resets our internal continuous angle, not the sensor itself
        # Useful if setting position without resetting the physical sensor zero
        current_internal_heading = (360 - self.inertial.heading()) % 360
        self.total_angle = current_internal_heading
        debug("Internal total angle reset to current heading: " + str(round(self.total_angle, 2)))

    def track_total_angle(self):
        # Needs to run in a separate thread
        debug("Starting inertial angle tracking thread...")
        # Initialize previous angle using the current sensor reading
        prev_internal_angle = (360 - self.inertial.heading()) % 360
        delta_time_msec = 15
        while True:
            current_vex_heading = self.inertial.heading()
            # Update total_angle and get the new internal angle for the next loop
            prev_internal_angle = self.update_turns_total(prev_internal_angle, current_vex_heading)
            # Optional: Add debug print for tracked angle
            # debug(f"Tracked Heading: {self.total_angle:.2f}")
            wait(delta_time_msec, MSEC)
        
    def print_heading(self):
         # Needs to run in a separate thread
        while True:
            debug("Current Internal Heading: " + str(round(self.heading(), 2)))
            wait(100, MSEC) # Print less frequently

# Position class is in src/tracker.py

class ControllerGUI:
    def __init__(self, controller: Controller):
        self.screen = controller.screen
    

    def overwrite_print(self, row, text):
        self.screen.set_cursor(row, 1) # Use 1-based indexing for VEX screen
        self.screen.clear_row(row)
        self.screen.print(text)
    

    def print_at_cursor(self, row, column, text):
        self.screen.set_cursor(row, column) # Use 1-based indexing
        # The VEX print command doesn't take row/col, set_cursor handles it
        self.screen.print(text)
    


class TankDrive:
    def __init__(self, wheel_diameter, gear_ratio, stopping_mode, left_drive_smart, right_drive_smart) -> None:
        self.left_drive_smart = left_drive_smart
        self.right_drive_smart = right_drive_smart
        self.wheel_diameter = wheel_diameter
        self.gear_ratio = gear_ratio # External Gear Ratio (e.g., 36/48 for 3:4)
        # Assuming internal motor gearing is handled by GearSetting enum
        self.stopping_mode = stopping_mode
        self.left_drive_smart.set_stopping(self.stopping_mode)
        self.right_drive_smart.set_stopping(self.stopping_mode) # Apply to both sides
        debug("TankDrive initialized.")

    
    def _percent_to_mvolt(self, percent):
        # Converts percent (-100 to 100) to millivolts (-12000 to 12000)
        return percent * 120
    

    def update_stopping_mode(self, stopping_mode):
        self.stopping_mode = stopping_mode
        self.left_drive_smart.set_stopping(self.stopping_mode)
        self.right_drive_smart.set_stopping(self.stopping_mode)
        debug("Drivetrain stopping mode set to: " + str(stopping_mode))

    
    def _spin(self, dir, motor_group, percent_speed):
        # Ensure percent_speed is within bounds
        percent_speed = max(-100, min(100, percent_speed))
        mvolt = self._percent_to_mvolt(percent_speed)
        # Spin command uses voltage, not millivolts directly in VEX Python (unlike C++)
        voltage = mvolt / 1000.0 
        motor_group.spin(dir, voltage, VOLT)

    def _convert_wheel_rotation_to_inches(self, rotations) -> float:
        # Distance = rotations * circumference
        circumference = self.wheel_diameter * math.pi
        return rotations * circumference
    
    def _get_side_distance(self, side) -> float:
        motor_group = self.left_drive_smart if side == LEFT else self.right_drive_smart
        # Get position in turns, apply gear ratio, convert to inches
        rotations = motor_group.position(TURNS)
        # Apply external gear ratio (e.g., if motor spins faster than wheel)
        wheel_rotations = rotations * self.gear_ratio 
        distance_inches = self._convert_wheel_rotation_to_inches(wheel_rotations)
        # debug(f"{side} side raw turns: {rotations:.3f}, wheel turns: {wheel_rotations:.3f}, dist: {distance_inches:.3f}")
        return distance_inches
    
    def _reset_drive_position(self) -> None:
        self.left_drive_smart.reset_position()
        self.right_drive_smart.reset_position()
        debug("Drive motor positions reset.")

    def _stop_drivetrain(self):
        self.left_drive_smart.stop()
        self.right_drive_smart.stop()
        # debug("Drivetrain stopped.") # Can be noisy
    
# WallGuideSensor class is in src/tracker.py

# DriveTracker class is in src/tracker.py

# Router class is in src/control/path_planning.py

# --- New Chassis Interface Class --- 
class Chassis:
    def __init__(self, 
                 left_motor_group: MotorGroup, 
                 right_motor_group: MotorGroup, 
                 inertial_port: Ports, 
                 gear_ratio: float, 
                 drive_wheel_diameter: float, 
                 odom_wheel_diameter: float, 
                 vertical_odom_port: Ports,
                 horizontal_odom_port: Ports,
                 right_wall_guide_port: Ports, # Optional sensors
                 left_wall_guide_port: Ports
                 ) -> None:
        
        debug("Initializing Chassis...")
        self.inertial = CustomInertial(inertial_port)
        self.inertial.calibrate()
        Thread(self.inertial.track_total_angle) 
        debug("Inertial sensor initialized and tracking started.")

        # 2. Initialize Drivetrain Base
        self.drivetrain = TankDrive(
            drive_wheel_diameter, 
            gear_ratio, 
            COAST, # Default stopping mode
            left_motor_group, 
            right_motor_group
        )
        debug("TankDrive component initialized.")

        # 3. Initialize Position Tracker
        self.tracker = DriveTracker(
            self.inertial, 
            vertical_odom_port, 
            horizontal_odom_port, 
            right_wall_guide_port, 
            left_wall_guide_port, 
            odom_wheel_diameter
        )
        # Start position tracking in a background thread
        Thread(self.tracker.track_position)
        debug("DriveTracker initialized and tracking started.")

        # 4. Initialize Path Planning Router
        self.router = Paths(self.tracker)
        debug("Router initialized.")

        # 5. Initialize Movement Controller
        self.movement = Movement(
            self.inertial,
            self.drivetrain,
            self.tracker,
            self.router
        )
        debug("Movement controller initialized.")

        debug("Chassis initialization complete.")

    # --- Delegate methods to Movement class --- 
    # Expose movement methods through the Chassis interface
    
    def turn_to_point(self, *args, **kwargs):
        """Delegates to Movement.turn_to_point"""
        return self.movement.turn_to_point(*args, **kwargs)

    def turn_to_heading(self, *args, **kwargs):
        """Delegates to Movement.turn_to_heading"""
        return self.movement.turn_to_heading(*args, **kwargs)

    def drive_along_angle(self, *args, **kwargs):
        """Delegates to Movement.drive_along_angle"""
        return self.movement.drive_along_angle(*args, **kwargs)
    
    def arc_along_points(self, *args, **kwargs):
        """Delegates to Movement.arc_along_points"""
        return self.movement.arc_along_points(*args, **kwargs)
    
    def move_to_pos(self, *args, **kwargs):
        """Delegates to Movement.move_to_pos"""
        return self.movement.move_to_pos(*args, **kwargs)
    
    def drive_to_pos(self, *args, **kwargs):
        """Delegates to Movement.drive_to_pos"""
        return self.movement.drive_to_pos(*args, **kwargs)
    
    def tune_odom_offset(self, *args, **kwargs):
        """Delegates to Movement.tune_odom_offset"""
        return self.movement.tune_odom_offset(*args, **kwargs)
    
    # --- Other useful methods --- 
    def set_pose(self, x: float, y: float, heading: float):
        new_pos = Position((x, y), heading)
        self.tracker.init_position(new_pos) # Use init which also sets inertial
        debug("Position manually set to: X=" + str(round(x, 2)) + ", Y=" + str(round(y, 2)) + ", H=" + str(round(heading, 2)))

    def get_position(self) -> Position:
        """Returns the current tracked position."""
        return self.tracker.position
        
    def stop_all_movement(self):
        """Stops the drivetrain motors."""
        self.drivetrain._stop_drivetrain()
        debug("All movement stopped via Chassis interface.")

    def set_drive_stopping_mode(self, mode):
        """Sets the stopping mode (BRAKE, COAST, HOLD) for the drivetrain."""
        self.drivetrain.update_stopping_mode(mode)

# --- End of New Chassis Class ---


# Robot configuration code
controller_1 = Controller(PRIMARY)
controller_gui = ControllerGUI(controller_1)

left_motor_a = Motor(Ports.PORT14 , GearSetting.RATIO_6_1, True)
left_motor_b = Motor(Ports.PORT15, GearSetting.RATIO_6_1, True)
left_motor_c = Motor(Ports.PORT16, GearSetting.RATIO_6_1, False)
left_drive_smart = MotorGroup(left_motor_a, left_motor_b, left_motor_c)

right_motor_a = Motor(Ports.PORT13, GearSetting.RATIO_6_1, False) #outdated
right_motor_b = Motor(Ports.PORT11, GearSetting.RATIO_6_1, False)
right_motor_c = Motor(Ports.PORT12, GearSetting.RATIO_6_1, True) 
right_drive_smart = MotorGroup(right_motor_a, right_motor_b, right_motor_c)

# Instantiate the new Chassis class
chassis = Chassis(
    left_motor_group=left_drive_smart,
    right_motor_group=right_drive_smart,
    gear_ratio=36/48, # External ratio
    drive_wheel_diameter=2.75,
    odom_wheel_diameter=2,
    inertial_port=Ports.PORT2, # type: ignore
    vertical_odom_port=Ports.PORT18, # type: ignore
    horizontal_odom_port=Ports.PORT17, # type: ignore
    right_wall_guide_port=Ports.PORT7, # type: ignore
    left_wall_guide_port=Ports.PORT21 # type: ignore
)

# wait for rotation sensor to fully initialize (moved after chassis init)
# wait(50, MSEC) # Removed, inertial calibration handles waiting


def play_vexcode_sound(sound_name):
    # Example: play_vexcode_sound("Tada")
    print("VEXPlaySound:" + sound_name)
    wait(5, MSEC) # Small delay to ensure the message is sent

# Initial setup prints/sounds
wait(200, MSEC)
print("\033[2J") # Clear terminal screen
play_vexcode_sound("PowerUp") 
debug("Robot Initialized.")

#Controller Code

# Global flag to enable/disable RC control
remote_control_code_enabled = False

drivetrain_l_needs_to_be_stopped_controller_1 = False
drivetrain_r_needs_to_be_stopped_controller_1 = False

# define a task that will handle monitoring inputs from controller_1
def get_drivetrain_speeds() -> Tuple[float, float]:
    # Tank drive control with Axis3 (forward/backward) and Axis1 (turning)
    # Apply a cubic scaling for finer control near the center
    forward_speed = controller_1.axis3.position()
    turn_speed = controller_1.axis1.position()
    
    # Simple cubic scaling: (pos / 100)^3 * 100
    scaled_forward = math.copysign( (abs(forward_speed) / 100.0)**3 * 100.0, forward_speed)
    scaled_turn = math.copysign( (abs(turn_speed) / 100.0)**3 * 100.0, turn_speed)

    drivetrain_left_side_speed = scaled_forward + scaled_turn
    drivetrain_right_side_speed = scaled_forward - scaled_turn
    
    # Clamp speeds to +/- 100
    drivetrain_left_side_speed = max(-100, min(100, drivetrain_left_side_speed))
    drivetrain_right_side_speed = max(-100, min(100, drivetrain_right_side_speed))

    return drivetrain_left_side_speed, drivetrain_right_side_speed 

def turn_on_rc_enabled():
    global remote_control_code_enabled
    remote_control_code_enabled = True
    debug("RC Control Enabled.")

def rc_auto_loop_function_controller_1():
    global drivetrain_l_needs_to_be_stopped_controller_1, drivetrain_r_needs_to_be_stopped_controller_1, remote_control_code_enabled
    
    # Set drive mode for RC
    chassis.set_drive_stopping_mode(COAST)
    
    while True:
        if remote_control_code_enabled:
            drivetrain_left_side_speed, drivetrain_right_side_speed = get_drivetrain_speeds()
            
            # Left Motor Control
            if abs(drivetrain_left_side_speed) < 5.0: # Deadband threshold
                if drivetrain_l_needs_to_be_stopped_controller_1:
                    chassis.drivetrain.left_drive_smart.stop()
                    drivetrain_l_needs_to_be_stopped_controller_1 = False
            else:
                 chassis.drivetrain._spin(FORWARD, chassis.drivetrain.left_drive_smart, drivetrain_left_side_speed)
                 drivetrain_l_needs_to_be_stopped_controller_1 = True # Mark as needing stop if speed goes to 0
            
            # Right Motor Control
            if abs(drivetrain_right_side_speed) < 5.0: # Deadband threshold
                if drivetrain_r_needs_to_be_stopped_controller_1:
                    chassis.drivetrain.right_drive_smart.stop()
                    drivetrain_r_needs_to_be_stopped_controller_1 = False
            else:
                 chassis.drivetrain._spin(FORWARD, chassis.drivetrain.right_drive_smart, drivetrain_right_side_speed)
                 drivetrain_r_needs_to_be_stopped_controller_1 = True # Mark as needing stop if speed goes to 0
            
        else:
            # If RC is disabled, ensure motors are stopped
            if drivetrain_l_needs_to_be_stopped_controller_1:
                 chassis.drivetrain.left_drive_smart.stop()
                 drivetrain_l_needs_to_be_stopped_controller_1 = False
            if drivetrain_r_needs_to_be_stopped_controller_1:
                 chassis.drivetrain.right_drive_smart.stop()
                 drivetrain_r_needs_to_be_stopped_controller_1 = False
                 
        wait(20, MSEC) # Loop delay

def autonomous():
    debug("Autonomous Routine Started")
    # --- Example Autonomous Sequence --- 
    chassis.set_drive_stopping_mode(BRAKE) # Use BRAKE for autonomous precision
    chassis.set_pose(x=10, y=10, heading=0) # Set starting position
    
    # Move to a point
    debug("Moving to (50, 10)...")
    chassis.move_to_pos(point=(50, 10), dir=FORWARD, turn_speed=50, drive_speed=70, ramp_up_ratio=0.2, min_ru=15)
    debug("Reached (50, 10).")
    wait(500, MSEC)
    
    # Turn to a heading
    debug("Turning to 90 degrees...")
    chassis.turn_to_heading(base_speed=60, desired_heading=90)
    debug("Turn complete.")
    wait(500, MSEC)

    # Drive along a path
    debug("Driving along path...")
    path = [(50, 50), (20, 50)]
    chassis.arc_along_points(base_speed=80, points=path, dir=FORWARD, ramp_up_ratio=0.1, min_ru=20, look_ahead=5)
    debug("Path complete.")
    
    # --- End Example --- 
    chassis.stop_all_movement()
    debug("Autonomous Routine Finished")

# Setup competition controller
# The user auton/driver functions are passed here
comp = Competition(rc_auto_loop_function_controller_1, autonomous)

# --- Pre-Autonomous Setup --- 
# Potentially run calibration or sensor checks here before comp starts
debug("Running Pre-Autonomous Setup...")
# Example: Ensure inertial is calibrated (already done in Chassis init)
# if not chassis.inertial.is_calibrating(): # Check if it finished
#    pass # Already done

debug("Pre-Autonomous Setup Complete. Ready for competition.")
