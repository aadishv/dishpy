from vex import *
import math
# Use absolute imports from src root
from constants import drive_constants
# Assuming CustomInertial, debug, timer are defined in or imported into main.py
from main import CustomInertial, debug, timer

class Position:
    def __init__(self, point: tuple, heading: float) -> None:
        self.x = point[0]
        self.y = point[1]
        self.heading = heading

class WallGuideSensor:
    def __init__(self, distance_port, heading_offset, x_off, y_off) -> None:
        self.distance_sensor = Distance(distance_port)
        self.heading_offset = heading_offset
        self.x_offset = x_off
        self.y_offset = y_off
    
    def get_distance_to_tracking_point(self, heading, wall_angle):
        heading_against_wall = (heading + self.heading_offset) - wall_angle
        return math.cos(math.radians(heading_against_wall)) * self.distance_sensor.object_distance(INCHES) + math.cos(math.radians(heading_against_wall)) * self.x_offset - math.sin(math.radians(heading_against_wall)) * self.y_offset

class DriveTracker:
    def __init__(self, inertial: CustomInertial, vertical_odom_port, horizontal_odom_pod, right_wall_guide_port, left_wall_guide_port, wheel_diameter):
        self.inertial = inertial
        self.position = Position((8.75, 7.25), 0)
        #assuming robot is facing 0deg global
        self.vertical_tracker = Rotation(vertical_odom_port)
        self.horizontal_tracker = Rotation(horizontal_odom_pod, True)
        self.vertical_tracker.reset_position()
        self.horizontal_tracker.reset_position()
        self.vertical_offset = 1/8  #inches
        # self.horizontal_offset = -(1/8 + 1/16)
        self.horizontal_offset = 0
        self.dt = 3
        self.wheel_diameter = wheel_diameter #INCHES
        self.distance_to_track = [None, None]

        self.right_wall_guide_sensor = WallGuideSensor(right_wall_guide_port, -90, 5 + 5/8, -(3 + 5/8))
        self.left_wall_guide_sensor = WallGuideSensor(left_wall_guide_port, 90, 5 + 5/8, 3 + 5/8)


        '''
        Settings

        POSITION
        Origin is bottom-left corner

        HEADING
        0 degrees is facing positive corner wallstake
        90 degrees is facing blue alliance
        180 degrees is facing negative 
        270 degrees is facing red alliance
        Robot preroller side is heading

        From bottom-left corner of robot 
        ASSUMING THAT 0DEG IS FRONT PRE-ROLLER (localized)
        
        outdated
        #X-add: 6.90625 in
        #Y-add: 6 in
        '''
    
    def get_vertical_distance(self):
        return self.vertical_tracker.position(TURNS) * self.wheel_diameter * math.pi
    
    def get_horizontal_distance(self):
        return self.horizontal_tracker.position(TURNS) * self.wheel_diameter * math.pi
    
    def _convert_rad_to_deg(self, rad):
        return rad * (180/math.pi)
    

    def _convert_deg_to_rad(self, deg):
        return deg / (180/math.pi)
    

    def get_vertical_offset(self, heading_delta):
        return self._convert_deg_to_rad(heading_delta) * self.vertical_offset
    
    def get_horizontal_offset(self, heading_delta):
        return self._convert_deg_to_rad(heading_delta) * self.horizontal_offset
    

    def get_x_traveled_vertical(self, distance_traveled, heading):
        #OUTPUT UNITS IS THE SAME AS INPUT UNITS
        return math.cos(self._convert_deg_to_rad(heading)) * distance_traveled

    
    def get_y_traveled_vertical(self, distance_traveled, heading):
        #OUTPUT UNITS IS THE SAME AS INPUT UNITS
        return math.sin(self._convert_deg_to_rad(heading)) * distance_traveled
    

    def get_x_traveled_horizontal(self, distance_traveled, heading):
        return math.cos(self._convert_deg_to_rad(heading - 90)) * distance_traveled
    

    def get_y_traveled_horizontal(self, distance_traveled, heading):
        return math.sin(self._convert_deg_to_rad(heading - 90)) * distance_traveled
    

    def set_position(self, position):
        self.position = position


    def init_position(self, position):
        self.position = position
        self.inertial.set_heading(position.heading)
    
    def track_distance(self, distance_sensor, wall_angle):
        distance_reading = 0
        if distance_sensor == LEFT:
            distance_reading = self.left_wall_guide_sensor.get_distance_to_tracking_point(self.position.heading, wall_angle)
        elif distance_sensor == RIGHT:
            distance_reading = self.right_wall_guide_sensor.get_distance_to_tracking_point(self.position.heading, wall_angle)

        if wall_angle == 0:
            self.position.x = 141 - distance_reading
        elif wall_angle == 90:
            self.position.y = 141 - distance_reading
        elif wall_angle == 180: 
            self.position.x = distance_reading
        elif wall_angle == 270:
            self.position.y = distance_reading
        
    
    def set_distance_to_track(self, distance_sensor, wall_angle):
        self.distance_to_track = [distance_sensor, wall_angle]

    def clear_distance_to_track(self):
        self.distance_to_track = [None, None]    
            

    def track_position(self):
        current_position = self.position
        previous_position = self.position
        current_vertical_distance = 0
        previous_vertical_distance = 0
        current_horizontal_distance = 0
        previous_horizontal_distance = 0
        while True:
            current_position = self.position
            heading_delta = current_position.heading - previous_position.heading
            vertical_offset = self.get_vertical_offset(heading_delta)
            horizontal_offset = self.get_horizontal_offset(heading_delta)
            current_vertical_distance = self.get_vertical_distance() - vertical_offset
            current_horizontal_distance = self.get_horizontal_distance() - horizontal_offset
            vertical_delta = current_vertical_distance - previous_vertical_distance
            horizontal_delta = current_horizontal_distance - previous_horizontal_distance
            x_delta = (self.get_x_traveled_vertical(vertical_delta, current_position.heading) + self.get_x_traveled_horizontal(horizontal_delta, current_position.heading))
            y_delta = (self.get_y_traveled_vertical(vertical_delta, current_position.heading) + self.get_y_traveled_horizontal(horizontal_delta, current_position.heading))
            self.set_position(Position((current_position.x + x_delta, current_position.y + y_delta), self.inertial.heading()))
            previous_position = current_position
            previous_vertical_distance = current_vertical_distance
            previous_horizontal_distance = current_horizontal_distance

            # debug("H off: " + str(round(horizontal_offset, 5)) + ", H dist: " + str(round(self.get_horizontal_distance(), 5)))
            # debug("V off: " + str(round(vertical_offset, 5)) + ", V dist: " + str(round(self.get_vertical_distance(), 5)))
            # debug("H dist: " + str(round(current_horizontal_distance, 5)))
            # debug("V dist: " + str(round(current_vertical_distance, 5)))
            # debug("---")

            if self.distance_to_track != [None, None]:
                self.track_distance(self.distance_to_track[0], self.distance_to_track[1])

            wait(self.dt, MSEC)

            

    def print_drive_position(self):
        while True:
            debug("x: " + str(self.position.x) + ", y:" + str(self.position.y) + ", heading: " + str(self.position.heading))
            wait(self.dt, MSEC)
    
    def get_right_sensor_distance(self):
        while True:
            heading = self.inertial.heading()
            distance = self.right_wall_guide_sensor.get_distance_to_tracking_point(heading, 270)
            #debug("distance: " + str(distance))
            wait(self.dt, MSEC) 