import math
from vex import *

# Use absolute imports from src root
from main import CustomInertial, TankDrive, debug, timer
from tracker import DriveTracker
from control.path_planning import Paths
from constants import drive_constants

class ControllerSettings:
    """Holds PID controller constants."""
    def __init__(self, Kp: float, Ki: float, Kd: float, integral_limit: float = 0.0, slew: float = 0.0):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.integral_limit = abs(integral_limit) # Ensure limit is positive
        self.slew = slew

class Movement:
    def __init__(self, 
                 inertial: CustomInertial,
                 drivetrain: TankDrive,
                 tracker: DriveTracker,
                 router: Paths
                 ) -> None:
        self.inertial = inertial
        self.drivetrain = drivetrain
        self.tracker = tracker
        self.router = router

        # PID/PD Settings using ControllerSettings class (with integral_limit=0)
        self.drive_side_PID_settings = ControllerSettings(Kp=23, Ki=0, Kd=3, integral_limit=0, slew=0.0)
        self.turn_side_PID_settings = ControllerSettings(Kp=18, Ki=0, Kd=0.2, integral_limit=0, slew=0.0)
        self.drive_angle_side_PID_settings = ControllerSettings(Kp=3.5, Ki=0, Kd=2, integral_limit=0, slew=0.0)
        self.arc_along_points_side_PID_settings_aggressive = ControllerSettings(Kp=1.7, Ki=0, Kd=1, integral_limit=0)
        self.arc_along_points_side_PID_settings_calm = ControllerSettings(Kp=1.4, Ki=0, Kd=1, integral_limit=0, slew=0.0)
        self.drive_accel_PD_settings_accel_calm = ControllerSettings(Kp=3, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.drive_accel_PD_settings_accel_medium = ControllerSettings(Kp=6.3, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.drive_accel_PD_settings_accel_aggressive = ControllerSettings(Kp=8, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.drive_accel_PD_settings_accel_reverse = ControllerSettings(Kp=10, Ki=0, Kd=0, integral_limit=0, slew=0.0)
        self.drive_angle_side_PD_accel_settings = ControllerSettings(Kp=4, Ki=0, Kd=0.2, integral_limit=0, slew=0.0) 
        self.turn_to_point_accel_PD_settings = ControllerSettings(Kp=2, Ki=0, Kd=9.5, integral_limit=0, slew=0.0)
        self.goal_rush_PD_accelsettings = ControllerSettings(Kp=10, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.arc_accel_PD_settings_calm = ControllerSettings(Kp=3, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.arc_accel_PD_settings_medium = ControllerSettings(Kp=4.6, Ki=0, Kd=1, integral_limit=0, slew=0.0)
        self.arc_accel_PD_settings_aggressive = ControllerSettings(Kp=8, Ki=0, Kd=0.3, integral_limit=0, slew=0.0)
        self.turn_accel_PD_accel_settings = ControllerSettings(Kp=2, Ki=0, Kd=9.5, integral_limit=0)

    
    def _manage_ramp_up(self, speed, desired_dist, current_dist, ratio, min_speed = 10):
        try: 
            ramp_up_dist = abs(desired_dist) * ratio # Use abs for desired_dist
            if ramp_up_dist < 1e-6: # Avoid division by zero if desired_dist or ratio is zero
                return min_speed if desired_dist > 0 else -min_speed
            # Calculate target speed magnitude
            target_speed_mag = (abs(speed) - min_speed) / ramp_up_dist * abs(current_dist) + min_speed
            return_val_mag = 0

            if target_speed_mag > abs(speed):
                return_val_mag = abs(speed)
            elif target_speed_mag < min_speed:
                return_val_mag = min_speed
            else:
                return_val_mag = target_speed_mag
            # debug("ramp_up_speed: " + str(return_val))
            # Apply original sign based on desired_dist or original speed sign
            return return_val_mag if speed >= 0 else -return_val_mag
        except ZeroDivisionError: # Should be caught by the check above, but keep for safety
             return min_speed if speed >= 0 else -min_speed

    # Consolidated PID control function
    def pid_control(self, control_constants: ControllerSettings, error, previous_integral, previous_error, delta_time):
        Kp = control_constants.Kp
        Ki = control_constants.Ki
        Kd = control_constants.Kd
        integral_limit = control_constants.integral_limit

        proportional = error
        # Update integral term
        integral = previous_integral + delta_time * error
        # Apply anti-windup clamping
        if integral_limit > 0:
            integral = max(-integral_limit, min(integral_limit, integral))
        
        # Avoid division by zero if delta_time is very small
        derivative = (error - previous_error) / delta_time if delta_time > 1e-6 else 0.0

        # Calculate raw PID output
        total_output = (proportional * Kp) + (integral * Ki) + (derivative * Kd)

        return total_output, integral

    def get_distance_to_center_line(self, start_position, end_position):
        x1, y1 = start_position
        x2, y2 = end_position
        robot_x, robot_y = self.tracker.position.x, self.tracker.position.y

        dx = x2 - x1
        dy = y2 - y1
    
        line_mag_sq = dx**2 + dy**2
        if line_mag_sq < 1e-9:
            return math.sqrt((robot_x - x1)**2 + (robot_y - y1)**2)
        A = dy
        B = -dx
        C = -A * x1 - B * y1

        numerator = A * robot_x + B * robot_y + C
        # Avoid division by zero
        denominator = math.sqrt(line_mag_sq) if line_mag_sq > 1e-9 else 1.0

        signed_distance = numerator / denominator

        # Positive distance means robot is to the RIGHT of the line segment (start -> end)
        # Negative distance means robot is to the LEFT of the line segment (start -> end)
        return signed_distance

    def turn_to_point(self, base_speed, point, dir):
        starting_l_position = self.drivetrain._get_side_distance(LEFT)
        starting_r_position = self.drivetrain._get_side_distance(RIGHT)
        integral = 0
        accel_integral = 0
        intial_heading_error = self.router.get_heading_gain(point, dir)
        distance_to_target_heading = self.router.get_heading_gain(point, dir)
        debug("Heading gain: " + str(distance_to_target_heading))
        previous_distance_to_target = distance_to_target_heading
        previous_distance_to_center_line = 0
        delta_time_sec = 0.01 # Use seconds for calculations
        delta_time_msec = int(delta_time_sec * 1000)

        debug("Current position - X: " + str(self.tracker.position.x) + ", Y: " + str(self.tracker.position.y) + ", Theta: " + str(self.tracker.position.heading))
        #anti-stuck
        previous_speed = 0
        stuck_counter = 0
        timeout_counter = 0 # Added timeout counter
        max_timeout_count = 300 # e.g., 3 seconds timeout

        while (abs(distance_to_target_heading) > 0.5):
            current_l_position = self.drivetrain._get_side_distance(LEFT) - starting_l_position
            current_r_position = self.drivetrain._get_side_distance(RIGHT) - starting_r_position

            distance_to_turn_point = abs(current_l_position) - abs(current_r_position) # Wheel distance diff
            distance_to_target_heading = self.router.get_heading_gain(point, dir)
            
            # Use PD controller for speed based on heading error
            speed, accel_integral = self.pid_control(
                self.turn_to_point_accel_PD_settings, 
                distance_to_target_heading, 
                accel_integral, 
                previous_distance_to_target, 
                delta_time_sec
            )

            # Use PID controller for side adjustment based on wheel distance difference
            # Calculate raw PID output for steering
            raw_adjustment_output, integral = self.pid_control(
                self.turn_side_PID_settings, 
                distance_to_turn_point, 
                integral, 
                previous_distance_to_center_line, 
                delta_time_sec
            )
            # Scale adjustment speed by ratio of current speed to base speed
            speed_ratio = abs(speed / base_speed) if abs(base_speed) > 1e-6 else 1.0
            adjustment_speed = raw_adjustment_output * speed_ratio
            
            # Speeds for turning (opposite directions)
            left_speed = -speed - adjustment_speed
            right_speed = speed - adjustment_speed 
            # Note: Original code had drive_speeds[LEFT] *= -1, 
            # which is equivalent to swapping signs or applying adjustment differently.
            # This version applies adjustment symmetrically and negates left for turn.

            self.drivetrain._spin(FORWARD, self.drivetrain.left_drive_smart, left_speed)
            self.drivetrain._spin(FORWARD, self.drivetrain.right_drive_smart, right_speed)

            # Stuck detection
            if abs(distance_to_target_heading - previous_distance_to_target) < 0.08:
                stuck_counter += 1
            else:
                stuck_counter = 0 # Reset if moving
            
            if stuck_counter >= 30: # Reduced threshold slightly
                debug("Turn to Point - timeout triggered")
                break
            
            # Timeout check
            timeout_counter += 1
            if timeout_counter > max_timeout_count:
                 debug("Turn to Point - MAX timeout triggered")
                 break
            
            previous_distance_to_center_line = distance_to_turn_point
            previous_distance_to_target = distance_to_target_heading
            
            previous_speed = speed # Not used in stuck logic here, but kept for consistency
            wait(delta_time_msec, MSEC)
            
        self.drivetrain._stop_drivetrain()
    
    def turn_to_heading(self, base_speed, desired_heading):
        starting_l_position = self.drivetrain._get_side_distance(LEFT)
        starting_r_position = self.drivetrain._get_side_distance(RIGHT)
        integral = 0
        accel_integral = 0
        distance_to_target = ((desired_heading - self.tracker.position.heading)+ 180) % 360 - 180
        initial_distance_to_target = distance_to_target
        previous_distance_to_target = distance_to_target
        previous_distance_to_center_line = 0
        delta_time_sec = 0.01 # Use seconds
        delta_time_msec = int(delta_time_sec * 1000)

        #anti-stuck
        previous_speed = 0
        stuck_counter = 0
        timeout_counter = 0
        max_timeout_count = 300 # 3 seconds timeout

        while (abs(distance_to_target) > 0.4):
            current_l_position = self.drivetrain._get_side_distance(LEFT) - starting_l_position
            current_r_position = self.drivetrain._get_side_distance(RIGHT) - starting_r_position

            distance_to_turn_point = abs(current_l_position) - abs(current_r_position)
            distance_to_target = ((desired_heading - self.tracker.position.heading) + 180) % 360 - 180
            
            speed, accel_integral = self.pid_control(
                self.turn_accel_PD_accel_settings, 
                distance_to_target, 
                accel_integral, 
                previous_distance_to_target, 
                delta_time_sec
            )
            
            adjustment_speed, integral = self.pid_control(
                self.turn_side_PID_settings, 
                distance_to_turn_point, 
                integral, 
                previous_distance_to_center_line, 
                delta_time_sec
            )
            
            left_speed = -speed - adjustment_speed
            right_speed = speed - adjustment_speed

            self.drivetrain._spin(FORWARD, self.drivetrain.left_drive_smart, left_speed)
            self.drivetrain._spin(FORWARD, self.drivetrain.right_drive_smart, right_speed)

            # Stuck detection
            if abs(distance_to_target - previous_distance_to_target) < 0.05:
                stuck_counter += 1
            else:
                stuck_counter = 0
            
            if stuck_counter >= 30:
                debug("Turn to Heading - stuck timeout triggered")
                break
            
            # Timeout check
            timeout_counter += 1
            if timeout_counter > max_timeout_count:
                 debug("Turn to Heading - MAX timeout triggered")
                 break

            previous_distance_to_center_line = distance_to_turn_point
            previous_distance_to_target = distance_to_target

            previous_speed = speed # Not used here but kept
            wait(delta_time_msec, MSEC)
            
        self.drivetrain._stop_drivetrain()
    
    
    def drive_along_angle(self, base_speed, point: tuple, dir, ramp_up_ratio, min_ru, pd_aggressiveness=drive_constants.MEDIUM, function_timings=[None, None], timeout=None) -> None:
        integral = 0
        accel_integral = 0
        distance_to_target = self.router.get_signed_error_to_point(point)
        initial_distance_to_target = distance_to_target # Keep initial sign
        desired_distance = distance_to_target # Total distance to cover
        previous_distance_to_target = distance_to_target
        previous_distance_to_center_line = 0
        delta_time_sec = 0.01 # Use seconds
        delta_time_msec = int(delta_time_sec * 1000)
        starting_position = (self.tracker.position.x, self.tracker.position.y)

        #anti-stuck
        previous_speed = 0
        stuck_counter = 0
        start_time_msec = timer.time(MSEC)

        # Determine direction multiplier
        direction_multiplier = 1 if initial_distance_to_target >= 0 else -1
        base_speed_signed = abs(base_speed) * direction_multiplier
        min_ru_signed = abs(min_ru) * direction_multiplier

        while (distance_to_target * direction_multiplier > 0.1): # Exit when close to target or passed it
            distance_to_target = self.router.get_signed_error_to_point(point)
            distance_to_center_line = self.get_distance_to_center_line(starting_position, point)
            current_distance_traveled = desired_distance - distance_to_target

            ramp_up_speed = self._manage_ramp_up(base_speed_signed, desired_distance, current_distance_traveled, ramp_up_ratio, abs(min_ru_signed))
            
            # Select PD settings based on constant
            if pd_aggressiveness == drive_constants.AGGRESSIVE:
                pd_setting = self.drive_accel_PD_settings_accel_aggressive
            elif pd_aggressiveness == drive_constants.CALM:
                pd_setting = self.drive_accel_PD_settings_accel_calm
            else: # Default to MEDIUM
                pd_setting = self.drive_accel_PD_settings_accel_medium

            # PD control for speed towards target
            pd_speed, accel_integral = self.pid_control(
                pd_setting, 
                distance_to_target, # Error is distance remaining
                accel_integral, 
                previous_distance_to_target, # Use previous error for derivative
                delta_time_sec
            )

            # Execute timed functions
            if len(function_timings) > 1 and function_timings[0] is not None and abs(current_distance_traveled - function_timings[1]) < 1:
                func_to_run = function_timings[0]
                args = () # Default to empty tuple
                if len(function_timings) == 3 and function_timings[2] is not None:
                    # Ensure args is a tuple if provided
                    args = function_timings[2] if isinstance(function_timings[2], tuple) else (function_timings[2],)
                
                debug("Running timed function...")
                Thread(func_to_run, args) # type: ignore 
                function_timings = [None, None] # Prevent re-running

            # Choose speed: minimum of ramp-up and PD controlled speed (magnitudes)
            speed = 0
            if direction_multiplier > 0:
                 speed = min(ramp_up_speed, pd_speed)
            else: # Moving backwards
                 speed = max(ramp_up_speed, pd_speed) # Max of two negative numbers
            
            # PID control for steering correction
            adjustment_speed, integral = self.pid_control(
                self.drive_angle_side_PID_settings, 
                distance_to_center_line, 
                integral, 
                previous_distance_to_center_line, 
                delta_time_sec
            )
            
            # Scale adjustment speed by ratio of current speed to base speed
            speed_ratio = abs(speed / base_speed_signed) if abs(base_speed_signed) > 1e-6 else 1.0
            adjustment_speed = adjustment_speed * speed_ratio
            
            # Final drive speeds
            left_speed = speed - adjustment_speed
            right_speed = speed + adjustment_speed
            
            # Stuck detection based on speed change
            if abs(speed) < abs(base_speed_signed / 1.5) and abs(previous_speed - speed) < 0.05:
                stuck_counter += 1
            else:
                stuck_counter = 0
            
            if stuck_counter >= 50:
                debug("Drive Along Angle - stuck timeout triggered")
                break
            
            # Check external timeout
            elapsed_time_msec = timer.time(MSEC) - start_time_msec
            if timeout is not None and elapsed_time_msec > timeout:
                debug("Drive Along Angle - external timeout triggered")
                break
            
            previous_speed = speed

            self.drivetrain._spin(FORWARD, self.drivetrain.left_drive_smart, left_speed)
            self.drivetrain._spin(FORWARD, self.drivetrain.right_drive_smart, right_speed)
            
            previous_distance_to_center_line = distance_to_center_line
            previous_distance_to_target = distance_to_target
            
            wait(delta_time_msec, MSEC)
            
        self.drivetrain._stop_drivetrain()
    
    def arc_along_points(self, base_speed, points: list[tuple], dir, ramp_up_ratio, min_ru, look_ahead, pd_aggressiveness=drive_constants.MEDIUM, lock_last_point_heading=False, function_point=[None, None]):
        # This function is complex and uses a mix of point-following and line-following.
        # It might need significant review after refactoring.
        # Consider simplifying the logic or breaking it down further.
        
        direction_multiplier = 1 if dir == FORWARD else -1 # Assuming FORWARD/REVERSE defined
        base_speed_signed = abs(base_speed) * direction_multiplier
        min_ru_signed = abs(min_ru) * direction_multiplier

        for point_index in range(len(points)):
            debug("Point index: " + str(point_index))

            # Execute function at specific point index
            if len(function_point) > 1 and function_point[0] is not None and point_index == function_point[1]:
                func_to_run = function_point[0]
                args = () # Default to empty tuple
                if len(function_point) == 3 and function_point[2] is not None:
                    # Ensure args is a tuple if provided
                    args = function_point[2] if isinstance(function_point[2], tuple) else (function_point[2],)
                
                debug("Running point function at index " + str(point_index) + "...") # Simplified debug message
                Thread(func_to_run, args) # type: ignore 
                function_point = [None, None] # Prevent re-running

            point = points[point_index]
            is_last_point = (point_index == len(points) - 1)
            
            integral = 0
            accel_integral = 0
            distance_to_target = self.router.get_signed_error_to_point(point) 
            initial_distance_to_target = distance_to_target # Store initial direction
            desired_distance = distance_to_target # Total distance for this segment
            previous_distance_to_target = distance_to_target
            previous_distance_to_center_line = 0
            delta_time_sec = 0.01
            delta_time_msec = int(delta_time_sec * 1000)

            debug("Target Point " + str(point_index) + ": " + str(point))
            debug("Initial dist to target: " + str(round(initial_distance_to_target, 2)))
            debug("Initial heading err: " + str(round(self.router.get_heading_gain(point, dir), 2)))
            debug("Current loc - X: " + str(round(self.tracker.position.x, 2)) + ", Y: " + str(round(self.tracker.position.y, 2)))

            starting_position_for_segment = points[point_index - 1] if point_index > 0 else (self.tracker.position.x, self.tracker.position.y)
            
            if is_last_point:
                end_position = points[point_index]
                debug("Final Segment - Start: " + str(starting_position_for_segment) + ", End: " + str(end_position))

            #anti-stuck
            previous_speed = 0
            stuck_counter = 0
            timeout_counter = 0
            max_timeout_count = 1000 # 10 seconds per segment timeout
            
            while True:
                # Calculate distance to target point along current heading
                distance_to_target = self.router.get_signed_error_to_point(point)
                current_distance_traveled = desired_distance - distance_to_target

                # --- Steering Control --- 
                if is_last_point and lock_last_point_heading:
                    # For the last point, use line following correction
                    distance_to_center_line = self.get_distance_to_center_line(starting_position_for_segment, end_position)
                    pid_setting_side = self.drive_angle_side_PID_settings
                else:
                    # For intermediate points, use heading correction towards the *next* point (or current if last)
                    next_point_index = min(point_index + 1, len(points) - 1)
                    look_ahead_point = points[next_point_index]
                    distance_to_center_line = self.router.get_heading_gain(look_ahead_point, dir)
                    # Choose PID based on magnitude of heading error?
                    if abs(distance_to_center_line) > 90: # Arbitrary threshold
                        debug("Using Aggressive Arc PID")
                        pid_setting_side = self.arc_along_points_side_PID_settings_aggressive
                    else:
                        pid_setting_side = self.arc_along_points_side_PID_settings_calm

                # --- Speed Control --- 
                # Select PD settings based on constant
                if pd_aggressiveness == drive_constants.AGGRESSIVE:
                    pd_setting_accel = self.arc_accel_PD_settings_aggressive
                elif pd_aggressiveness == drive_constants.CALM:
                    pd_setting_accel = self.arc_accel_PD_settings_calm
                elif pd_aggressiveness == drive_constants.RUSH:
                    pd_setting_accel = self.goal_rush_PD_accelsettings
                else: # Default to MEDIUM
                    pd_setting_accel = self.arc_accel_PD_settings_medium

                ramp_up_speed = self._manage_ramp_up(base_speed_signed, desired_distance, current_distance_traveled, ramp_up_ratio, abs(min_ru_signed))
                
                pd_speed, accel_integral = self.pid_control(
                    pd_setting_accel, 
                    distance_to_target, 
                    accel_integral, 
                    previous_distance_to_target, 
                    delta_time_sec
                )
                                                                  
                # Determine segment speed profile
                speed_target = 0 # Renamed from 'speed'
                if point_index == 0:
                    # Start of path: Ramp up
                    speed_target = ramp_up_speed 
                elif is_last_point:
                    # End of path: Ramp down using PD
                    # Clamp PD speed
                    if abs(pd_speed) > abs(base_speed_signed):
                        pd_speed_clamped = base_speed_signed
                    elif abs(pd_speed) < abs(min_ru_signed):
                        pd_speed_clamped = min_ru_signed
                    else:
                        pd_speed_clamped = pd_speed
                        
                    if direction_multiplier > 0:
                        speed_target = min(base_speed_signed, pd_speed_clamped)
                    else:
                        speed_target = max(base_speed_signed, pd_speed_clamped)
                else:
                    # Middle of path: Maintain base speed (or maybe blend?)
                    speed_target = base_speed_signed 
            
                # Calculate steering adjustment (raw PID output)
                raw_adjustment_output, integral = self.pid_control(
                    pid_setting_side, 
                    distance_to_center_line, 
                    integral, 
                    previous_distance_to_center_line, 
                    delta_time_sec
                )
                # Scale adjustment speed
                speed_ratio = abs(speed_target / base_speed_signed) if abs(base_speed_signed) > 1e-6 else 1.0
                adjustment_speed = raw_adjustment_output * speed_ratio
                
                # Apply speeds
                left_speed = speed_target - adjustment_speed
                right_speed = speed_target + adjustment_speed
                
                # Handle reverse direction if needed (though PID signs should handle this?)
                # if dir == REVERSE:
                #     left_speed *= -1
                #     right_speed *= -1

                self.drivetrain._spin(FORWARD, self.drivetrain.left_drive_smart, left_speed)
                self.drivetrain._spin(FORWARD, self.drivetrain.right_drive_smart, right_speed)
                
                # --- Exit Conditions & Stuck Detection --- 
                # Stuck detection
                if abs(speed_target) < abs(base_speed_signed / 2) and abs(previous_speed - speed_target) < 0.05:
                    stuck_counter += 1
                else:
                    stuck_counter = 0
                
                if stuck_counter >= 100:
                    debug("Arc Along Points (Point " + str(point_index) + ") - stuck timeout triggered")
                    break
                
                # Timeout check
                timeout_counter += 1
                if timeout_counter > max_timeout_count:
                    debug("Arc Along Points (Point " + str(point_index) + ") - MAX timeout triggered")
                    break
                    
                previous_speed = speed_target # Update previous speed
                previous_distance_to_center_line = distance_to_center_line
                previous_distance_to_target = distance_to_target
                
                # Check if segment is complete
                exit_threshold = 0.1 if is_last_point else look_ahead
                if distance_to_target * initial_distance_to_target < 0: # Passed the point
                     debug("Passed point " + str(point_index))
                     break # Exit loop for this point
                if abs(distance_to_target) < exit_threshold:
                     debug("Reached threshold for point " + str(point_index))
                     break # Exit loop for this point
                     
                wait(delta_time_msec, MSEC)
                
            # Stop briefly between segments? Or rely on next segment's ramp-up?
            # self.drivetrain._stop_drivetrain() # Maybe remove this for smoother transitions
            if stuck_counter >= 100 or timeout_counter > max_timeout_count:
                # If timeout/stuck, break the entire arc path
                break

        self.drivetrain._stop_drivetrain() # Ensure stop at the very end
    
    def move_to_pos(self, point, dir, turn_speed, drive_speed, ramp_up_ratio, min_ru, pd_aggressiveness="medium", function_timings=[None, None], timeout=None):
        self.turn_to_point(turn_speed, point, dir)
        # Add a small pause maybe? wait(50, MSEC)
        self.drive_along_angle(drive_speed, point, dir, ramp_up_ratio, min_ru, pd_aggressiveness, function_timings=function_timings, timeout=timeout)
        debug("move_to_pos End point: (" + str(round(self.tracker.position.x, 2)) + ", " + str(round(self.tracker.position.y, 2)) + ")")

    def drive_to_pos(self, point, drive_speed, dir, ramp_up_ratio, min_ru, pd_aggressiveness="medium", function_timings=[None, None], timeout=None):
        # This assumes the robot is already facing the correct general direction.
        self.drive_along_angle(drive_speed, point, dir, ramp_up_ratio, min_ru, pd_aggressiveness, function_timings=function_timings, timeout=timeout)
        debug("drive_to_pos End point: (" + str(round(self.tracker.position.x, 2)) + ", " + str(round(self.tracker.position.y, 2)) + ")")
    
    def tune_odom_offset(self):
        # This function seems designed for tuning, potentially running indefinitely.
        # Ensure it's used appropriately.
        starting_l_position = self.drivetrain._get_side_distance(LEFT)
        starting_r_position = self.drivetrain._get_side_distance(RIGHT)
        integral = 0
        previous_distance_to_center_line = 0
        delta_time_sec = 0.01
        delta_time_msec = int(delta_time_sec * 1000)
        previous_x = self.tracker.position.x
        previous_y = self.tracker.position.y

        try:
            while True:
                x = self.tracker.position.x
                y = self.tracker.position.y

                delta_x = x - previous_x
                delta_y = y - previous_y
                # Log delta_x, delta_y, and current heading for tuning analysis
                debug("Tune - dX: " + str(round(delta_x, 4)) + ", dY: " + str(round(delta_y, 4)) + ", Head: " + str(round(self.tracker.position.heading, 2)))

                current_l_position = self.drivetrain._get_side_distance(LEFT) - starting_l_position
                current_r_position = self.drivetrain._get_side_distance(RIGHT) - starting_r_position
                distance_to_turn_point = abs(current_l_position) - abs(current_r_position)
                
                speed = 100 # Keep constant speed for turning
                
                adjustment_speed, integral = self.pid_control(
                    self.turn_side_PID_settings, 
                    distance_to_turn_point, 
                    integral, 
                    previous_distance_to_center_line, 
                    delta_time_sec
                )
                
                left_speed = -speed - adjustment_speed
                right_speed = speed - adjustment_speed

                self.drivetrain._spin(FORWARD, self.drivetrain.left_drive_smart, left_speed)
                self.drivetrain._spin(FORWARD, self.drivetrain.right_drive_smart, right_speed)
                
                previous_x = x
                previous_y = y
                previous_distance_to_center_line = distance_to_turn_point
                wait(delta_time_msec, MSEC)
        except Exception as e:
            debug("Error during tuning: " + str(e))
        finally:
            self.drivetrain._stop_drivetrain() 