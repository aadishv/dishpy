from vex import *

class DriveConstants:
    def __init__(self):
        self.CALM = "CALM"
        self.MEDIUM = "MEDIUM"
        self.AGGRESSIVE = "AGGRESSIVE"
        self.RUSH = "RUSH"

drive_constants = DriveConstants()
