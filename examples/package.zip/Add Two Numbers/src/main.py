"""
Template for the main.py file.

Eventually, DishPy will add better templates to achieve feature parity with VEXcode, but for now you're stuck with this empty file!
"""

from add_two_nums import add_two_numbers

print(add_two_numbers(6, 7))
